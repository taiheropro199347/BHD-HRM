﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStoresWebAPI.Models
{
    public class JWTSettings
    {
        public string SecretKey { get; set; }
    }
}
